﻿namespace Wordle.Shared
{
    public class Tries
    {

    }
}
